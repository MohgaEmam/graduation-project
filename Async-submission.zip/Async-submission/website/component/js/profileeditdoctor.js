// patient previous lists
const docName = document.querySelector('#doctorName');
const docSpec = document.querySelector('#doctorSpecialization');


// create element & render cafe
function renderHeaderData(doc){
    // patient current lists
    let li1 = document.createElement('h1');
    let li2 = document.createElement('h1');


    // patient current lists
    li1.setAttribute('data-id', doc.id);
    li1.textContent = doc.data().doctor;
    li2.textContent = doc.data().specialization;

    // patient current lists


    docName.appendChild(li1);
    docSpec.appendChild(li2)

};


// real-time listener
db.collection('clinc').orderBy('doctor').onSnapshot(snapshot => {
    let changes = snapshot.docChanges();
    changes.forEach(change => {
        console.log(change.doc.data());
        if(change.type == 'added'){
            renderHeaderData(change.doc);
        } else if (change.type == 'removed'){
            let li = cafeList.querySelector('[data-id=' + change.doc.id + ']');
            cafeList.removeChild(li);
        }
    });
});


document.addEventListener('DOMContentLoaded', function () {

    var modals = document.querySelectorAll('.modal');
    M.Modal.init(modals);
});

// save new contact


addContact = document.getElementById('addContact-form');

addContact.addEventListener('submit', (e) => {
    e.preventDefault();
    db.collection('clinc').add({
        patient: addContact.name.value,
        status: addContact.number.value
    });
    addContact.name.value = '';
    addContact.number.value = '';
});

// save new contact


addDoctor = document.getElementById('addDoctor-form');

addDoctor.addEventListener('submit', (e) => {
    e.preventDefault();
    db.collection('clinc').add({
        name: addDoctor.name.value,
        specialization: addDoctor.specialization.value
    });
    addDoctor.name.value = '';
    addDoctor.specialization.value = '';
});








// update data

docUpdate = document.getElementById('updateDoctor');

// patient previous lists
const cafeList = document.querySelector('#patientNameList');



// create element & render cafe
function renderCurrentData(doc) {
    // patient current lists
    let li1 = document.createElement('li');

    // patient current lists

    let disease = document.createElement('span');
    let doctor = document.createElement('span');
    let update = document.createElement('a');
    const cross = document.createElement('span');

    let nameVar = document.getElementById('updateContact-form');
    // patient current lists
    li1.setAttribute('data-id', doc.id);
    disease.textContent = doc.data().status;
    doctor.textContent = doc.data().patient;
    update.textContent = 'update';
    cross.textContent = 'X';

    cross.style.marginLeft = "100%";
    cross.style.marginBottom = "50%";
    disease.style.marginLeft = "100%";

    update.style.marginLeft = "180%";

    update.setAttribute('data-target', "modal-update");
    update.classList.add('modal-trigger');
    update.classList.add('messageDoctor');

    // patient current lists

    li1.appendChild(doctor);
    li1.appendChild(disease);
    li1.appendChild(update);
    li1.appendChild(cross);

    cafeList.appendChild(li1);

    // deleting data
    cross.addEventListener('click', (e) => {
        e.stopPropagation();
        let id = e.target.parentElement.getAttribute('data-id');
        console.log(id)
        db.collection('clinc').doc(id).delete();
    });

    update.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        const elem = document.getElementById('modal-update');
        const instance = M.Modal.init(elem, { dismissible: false });
        instance.open();
        let id = e.target.parentElement.getAttribute('data-id');
        nameVar.addEventListener('submit' , (n) => {
            n.preventDefault();
            db.collection('clinc').doc(id).update({
                patient: nameVar.contactUpdateName.value,
                status: nameVar.contactUpdateNumber.value
            });
            nameVar.contactUpdateName.value = '';
            nameVar.contactUpdateNumber.value = '';
        });
    });
};



// real-time listener
db.collection('clinc').orderBy('patient').onSnapshot(snapshot => {
    let changes = snapshot.docChanges();
    changes.forEach(change => {
        console.log(change.doc.data());
        if (change.type == 'added') {
            renderCurrentData(change.doc);
        } else if (change.type == 'removed') {
            let li = cafeList.querySelector('[data-id=' + change.doc.id + ']');
            cafeList.removeChild(li);
        }
    });
});



// patient previous lists
const docList = document.querySelector('#clincList');
const updateForm = document.getElementById('updateDoctor-form')


// create element & render cafe
function renderData(doc) {
    // patient current lists
    let li1 = document.createElement('li');

    // patient current lists

    let disease = document.createElement('span');
    let doctor = document.createElement('span');
    let update = document.createElement('a');
    const cross = document.createElement('span');


    // patient current lists
    li1.setAttribute('data-id', doc.id);
    disease.textContent = doc.data().specialization;
    doctor.textContent = doc.data().name;
    update.textContent = 'update';
    cross.textContent = 'X';

    cross.style.marginLeft = "50%";
    cross.style.marginBottom = "50%";
    disease.style.marginLeft = "100%";

    update.style.marginLeft = "100%";

    update.setAttribute('data-target', "modal-update");
    update.classList.add('modal-trigger');
    update.classList.add('messageDoctor');

    // patient current lists

    li1.appendChild(doctor);
    li1.appendChild(disease);
    li1.appendChild(update);
    li1.appendChild(cross);

    docList.appendChild(li1);

    let nameVar = document.getElementById('updateDoctor-form');

    // deleting data
    cross.addEventListener('click', (e) => {
        e.stopPropagation();
        let id = e.target.parentElement.getAttribute('data-id');
        console.log(id)
        db.collection('clinc').doc(id).delete();
    });

    update.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        const elem = document.getElementById('modal-doctor');
        const instance = M.Modal.init(elem, { dismissible: false });
        instance.open();
        let id = e.target.parentElement.getAttribute('data-id');
        nameVar.addEventListener('submit' , (n) => {
            n.preventDefault();
            db.collection('clinc').doc(id).update({
                name: nameVar.doctorName.value,
                specialization: nameVar.doctorSpecialization.value
            });
            nameVar.doctorName.value = '';
            nameVar.doctorSpecialization.value = '';
        });
    });

};

// real-time listener
db.collection('clinc').orderBy('name').onSnapshot(snapshot => {
    let changes = snapshot.docChanges();
    changes.forEach(change => {
        console.log(change.doc.data());
        if (change.type == 'added') {
            renderData(change.doc);
        } else if (change.type == 'removed') {
            let li = cafeList.querySelector('[data-id=' + change.doc.id + ']');
            cafeList.removeChild(li);
        }
    });
});