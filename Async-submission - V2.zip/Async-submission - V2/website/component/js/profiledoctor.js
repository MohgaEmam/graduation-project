// patient previous lists
const docName = document.querySelector('#doctorName');
const docSpec = document.querySelector('#doctorSpecialization');

docSpec.style.paddingLeft = '2%';

// create element & render cafe
function renderCurrentData(doc){
    // patient current lists
    let li1 = document.createElement('h1');
    let li2 = document.createElement('h1');


    // patient current lists
    li1.setAttribute('data-id', doc.id);
    li1.textContent = doc.data().doctor;
    li2.textContent = doc.data().specialization;

    // patient current lists


    docName.appendChild(li1);
    docSpec.appendChild(li2)

};


// real-time listener
db.collection('clinc').orderBy('doctor').onSnapshot(snapshot => {
    let changes = snapshot.docChanges();
    changes.forEach(change => {
        console.log(change.doc.data());
        if(change.type == 'added'){
            renderCurrentData(change.doc);
        } else if (change.type == 'removed'){
            let li = cafeList.querySelector('[data-id=' + change.doc.id + ']');
            cafeList.removeChild(li);
        }
    });
});



// patient previous lists


const cafeList = document.querySelector('#patientList');

// create element & render cafe
function renderData(doc){
    // patient current lists
    let li1 = document.createElement('li');

    // patient current lists

    let disease = document.createElement('span');
    let doctor = document.createElement('span');
    const cross = document.createElement('span');


    // patient current lists
    li1.setAttribute('data-id', doc.id);
    disease.textContent = doc.data().status;
    doctor.textContent = doc.data().patient;
    cross.textContent = 'X';

    disease.style.paddingLeft = "180%";

    cross.style.paddingLeft = "350%";
    cross.style.marginBottom = "150%"


    // plus.style.paddingLeft = "40%";

    // patient current lists

    li1.appendChild(doctor);
    li1.appendChild(disease);
    li1.appendChild(cross);
    // li1.appendChild(plus);

    cafeList.appendChild(li1);

    // deleting data
    cross.addEventListener('click', (e) => {
        e.stopPropagation();
        let id = e.target.parentElement.getAttribute('data-id');
        db.collection('clinc').doc(id).delete();
    });

};


// real-time listener
db.collection('clinc').orderBy('name').onSnapshot(snapshot => {
    let changes = snapshot.docChanges();
    changes.forEach(change => {
        console.log(change.doc.data());
        if(change.type == 'added'){
            renderData(change.doc);
        } else if (change.type == 'removed'){
            let li = cafeList.querySelector('[data-id=' + change.doc.id + ']');
            cafeList.removeChild(li);
        }
    });
});

auth.onAuthStateChanged(user => {
    if (user) {
      console.log('user logged in: ', user);
    } else {
      console.log('user logged out');
    }
  });


// logout
const logout = document.querySelector('#logout');
logout.addEventListener('click', (e) => {
  e.preventDefault();
  auth.signOut().then(() => {
    console.log('user signed out');
    location.replace('/index.html')
  })
});